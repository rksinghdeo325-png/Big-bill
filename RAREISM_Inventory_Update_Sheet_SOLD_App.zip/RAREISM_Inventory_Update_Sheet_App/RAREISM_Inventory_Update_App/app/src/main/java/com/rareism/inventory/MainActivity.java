package com.rareism.inventory;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.apache.poi.ss.usermodel.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_FILE = 1001;
    private EditText searchBox;
    private TextView statusText;
    private EditText soldQtyBox;
    private InventoryAdapter adapter;
    private final List<Item> allItems = new ArrayList<>();
    private final List<Item> shownItems = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        searchBox = findViewById(R.id.searchBox);
        statusText = findViewById(R.id.statusText);
        Button update = findViewById(R.id.updateButton);
        Button sold = findViewById(R.id.soldButton);
        soldQtyBox = findViewById(R.id.soldQtyBox);
        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(shownItems);
        rv.setAdapter(adapter);

        loadSavedOrBundled();
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ filter(s.toString()); }
            public void afterTextChanged(android.text.Editable e){}
        });
        update.setOnClickListener(v -> chooseFile());
        sold.setOnClickListener(v -> recordSold());
    }

    private void recordSold() {
        String qtyText = soldQtyBox.getText().toString().trim();
        String q = searchBox.getText().toString().trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "Search the style/barcode first.", Toast.LENGTH_SHORT).show();
            return;
        }
        int qty;
        try { qty = Integer.parseInt(qtyText); } catch(Exception e) { qty = 1; }
        if (qty <= 0) {
            Toast.makeText(this, "Enter a valid sold quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayList<Item> matches = new ArrayList<>();
        String qq = q.toLowerCase(Locale.ROOT);
        for (Item x : allItems) {
            String hay=(x.style+" "+x.barcode+" "+x.product+" "+x.colour+" "+x.size).toLowerCase(Locale.ROOT);
            if (hay.contains(qq)) matches.add(x);
        }

        if (matches.size() != 1) {
            Toast.makeText(this, matches.isEmpty()
                    ? "No matching item found."
                    : "Search must identify exactly one item before SOLD.", Toast.LENGTH_LONG).show();
            return;
        }

        Item x = matches.get(0);
        int current;
        try { current = Integer.parseInt(x.closing.replaceAll("[^0-9-]","")); }
        catch(Exception e) { current = 0; }

        if (qty > current) {
            Toast.makeText(this, "Sold qty is greater than current SOH ("+current+").", Toast.LENGTH_LONG).show();
            return;
        }
        x.closing = String.valueOf(current - qty);
        try {
            saveItems(allItems);
            filter(searchBox.getText().toString());
            statusText.setText("Sold "+qty+" | Updated SOH: "+x.closing+" | Real-time");
            soldQtyBox.setText("1");
            Toast.makeText(this, "Sale recorded successfully.", Toast.LENGTH_SHORT).show();
        } catch(Exception e) {
            Toast.makeText(this, "Could not save sale: "+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void chooseFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_FILE);
    }

    @Override protected void onActivityResult(int req,int result,@Nullable Intent data) {
        super.onActivityResult(req,result,data);
        if(req==PICK_FILE && result==Activity.RESULT_OK && data!=null && data.getData()!=null) {
            try {
                getContentResolver().takePersistableUriPermission(data.getData(),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch(Exception ignored) {}
            new Thread(() -> {
                try {
                    List<Item> imported = readExcel(data.getData());
                    if(imported.isEmpty()) throw new Exception("No inventory rows found.");
                    saveItems(imported);
                    runOnUiThread(() -> {
                        allItems.clear(); allItems.addAll(imported);
                        filter(searchBox.getText().toString());
                        statusText.setText("Updated: " + new SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.getDefault()).format(new Date()) +
                                "  |  " + allItems.size() + " rows");
                        Toast.makeText(this,"Inventory updated successfully",Toast.LENGTH_LONG).show();
                    });
                } catch(Exception e) {
                    runOnUiThread(() -> Toast.makeText(this,"Update failed: "+e.getMessage(),Toast.LENGTH_LONG).show());
                }
            }).start();
        }
    }

    private List<Item> readExcel(Uri uri) throws Exception {
        ArrayList<Item> out = new ArrayList<>();
        try(InputStream in = getContentResolver().openInputStream(uri);
            Workbook wb = WorkbookFactory.create(in)) {
            Sheet sheet = wb.getSheetAt(0);
            Row header = sheet.getRow(sheet.getFirstRowNum());
            if(header==null) throw new Exception("Header row not found.");
            Map<String,Integer> cols = new HashMap<>();
            for(Cell c: header) {
                String h = cell(c).trim().toLowerCase(Locale.ROOT);
                cols.put(h,c.getColumnIndex());
            }
            int styleCol = find(cols,"style");
            int sizeCol = find(cols,"size");
            int closingCol = find(cols,"closing","closing soh","soh");
            int barcodeCol = findOptional(cols,"barcode","bar code");
            int productCol = findOptional(cols,"product","product name");
            int colourCol = findOptional(cols,"colour","color","colour name");
            if(styleCol<0 || sizeCol<0 || closingCol<0)
                throw new Exception("Need Style, Size and CLOSING/SOH columns.");
            for(int r=sheet.getFirstRowNum()+1;r<=sheet.getLastRowNum();r++) {
                Row row=sheet.getRow(r); if(row==null) continue;
                String style=get(row,styleCol), size=get(row,sizeCol), closing=get(row,closingCol);
                String product=productCol>=0?get(row,productCol):"";
                String barcode=barcodeCol>=0?get(row,barcodeCol):"";
                String colour=colourCol>=0?get(row,colourCol):"";
                String combined=(style+" "+product).toLowerCase(Locale.ROOT);
                if((style.isEmpty() && barcode.isEmpty()) || combined.contains("total") || combined.contains("subtotal")) continue;
                out.add(new Item(style,barcode,product,colour,size,closing));
            }
        }
        return out;
    }

    private int find(Map<String,Integer> m,String... names){ return findOptional(m,names); }
    private int findOptional(Map<String,Integer> m,String... names){
        for(String n:names){ Integer i=m.get(n); if(i!=null) return i; }
        return -1;
    }
    private String get(Row r,int col){ return col<0?"":cell(r.getCell(col)); }
    private String cell(Cell c){
        if(c==null) return "";
        DataFormatter f=new DataFormatter();
        return f.formatCellValue(c).trim();
    }

    private void loadSavedOrBundled() {
        File f=new File(getFilesDir(),"inventory.csv");
        try {
            List<Item> items;
            if(f.exists()) items=readCsv(new FileInputStream(f));
            else items=readCsv(getAssets().open("inventory.csv"));
            allItems.addAll(items);
            filter("");
            statusText.setText("Inventory: "+allItems.size()+" rows");
        } catch(Exception e) { statusText.setText("Could not load inventory"); }
    }

    private List<Item> readCsv(InputStream in)throws Exception{
        ArrayList<Item> out=new ArrayList<>();
        BufferedReader br=new BufferedReader(new InputStreamReader(in));
        br.readLine();
        String line;
        while((line=br.readLine())!=null){
            String[] p=line.split(",",-1);
            if(p.length>=6) out.add(new Item(unq(p[0]),unq(p[1]),unq(p[2]),unq(p[3]),unq(p[4]),unq(p[5])));
        }
        br.close(); return out;
    }
    private String unq(String s){ return s.replace("\"\"","\"").replaceAll("^\"|\"$",""); }

    private void saveItems(List<Item> items)throws Exception{
        File f=new File(getFilesDir(),"inventory.csv");
        BufferedWriter bw=new BufferedWriter(new FileWriter(f));
        bw.write("style,barcode,product,colour,size,closing\n");
        for(Item x:items){
            bw.write(csv(x.style)+","+csv(x.barcode)+","+csv(x.product)+","+csv(x.colour)+","+csv(x.size)+","+csv(x.closing)+"\n");
        }
        bw.close();
    }
    private String csv(String s){ return "\""+s.replace("\"","\"\"")+"\""; }

    private void filter(String q){
        q=q.toLowerCase(Locale.ROOT).trim();
        shownItems.clear();
        int limit=1000;
        for(Item x:allItems){
            String hay=(x.style+" "+x.barcode+" "+x.product+" "+x.colour+" "+x.size).toLowerCase(Locale.ROOT);
            if(q.isEmpty() || hay.contains(q)){ shownItems.add(x); if(--limit==0) break; }
        }
        adapter.notifyDataSetChanged();
    }

    static class Item {
        String style,barcode,product,colour,size,closing;
        Item(String a,String b,String c,String d,String e,String f){style=a;barcode=b;product=c;colour=d;size=e;closing=f;}
    }

    static class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH>{
        List<Item> list; InventoryAdapter(List<Item> l){list=l;}
        public VH onCreateViewHolder(ViewGroup p,int v){return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_inventory,p,false));}
        public void onBindViewHolder(VH h,int i){
            Item x=list.get(i);
            h.a.setText("STYLE: "+x.style+"    SIZE: "+x.size);
            h.b.setText("SOH / CLOSING: "+x.closing);
            h.c.setText((x.product.isEmpty()?"":x.product+"  |  ")+(x.colour.isEmpty()?"":x.colour+"  |  ")+x.barcode);
        }
        public int getItemCount(){return list.size();}
        static class VH extends RecyclerView.ViewHolder{
            TextView a,b,c; VH(View v){super(v);a=v.findViewById(R.id.line1);b=v.findViewById(R.id.line2);c=v.findViewById(R.id.line3);}
        }
    }
}
